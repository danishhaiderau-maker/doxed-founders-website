Trading Sessions — Complete Bundle
Generated: 2026-06-26T01:33:46Z
History root: C:\Users\user\Desktop\Final Bots\doxedcryptofounder\services\btc-conservative-agent\research
Live root: C:\Users\user\Desktop\Final Bots\doxedcryptofounder\services\btc-conservative-agent\research

Contents:
  session_index.json          — flat list of all archived analyzer runs
  continuous_session_timeline.json — CONTINUOUS lane stats per archive snapshot
  continuous_weekend_breakdown.json — weekday vs weekend from trades CSV
  continuous_trades.csv       — every CONTINUOUS fill with day-of-week
  sessions/                   — full report tree per archived session (95 folders)
  live/                       — latest reports + summaries from live bot folder
  csv/                        — raw pipeline CSVs (trades, decisions, blocked)

Open continuous_session_timeline.json to see how CONTINUOUS PnL evolved across sessions.
Open continuous_weekend_breakdown.json for weekend vs weekday split.

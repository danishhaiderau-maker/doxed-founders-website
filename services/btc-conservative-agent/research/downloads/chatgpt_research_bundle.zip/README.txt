ChatGPT Research Bundle
Generated: 2026-06-24T10:59:10.868615+00:00
Total trades in CSV: 152
Session archives on disk: 82

Upload this entire ZIP to ChatGPT. Start with BUNDLE_MANIFEST.json and csv/trades_3factor.csv.

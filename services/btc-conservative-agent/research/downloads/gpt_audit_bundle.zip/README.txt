GPT Audit Bundle — Trading Genome v11
Generated: 2026-06-27T00:52:01.085340+00:00
Architecture: v11.0-genome-architecture-v1

UPLOAD THIS ENTIRE ZIP TO CHATGPT.

Start with:
  1. GPT_AUDIT_MANIFEST.json — versions, file list, DB stats
  2. IMPLEMENTATION_STATUS.json — what's implemented vs pending
  3. source/bot.py — main execution engine (Scenario C)
  4. source/research/analyzer_research_engine_v62.py — legacy analyzer loop
  5. source/research/genome/ — DNA-first persistent genome pipeline
  6. source/research_genome/ — bot-side recorders
  7. data/genome_analysis_report.json — latest genome analysis

Key philosophy:
  Bot records facts → research.db → Genome Memory → Discoveries → Recommendations → Human decides
  Analyzer NEVER changes execution automatically.

This bundle auto-regenerates every analyzer cycle (~30 min).
